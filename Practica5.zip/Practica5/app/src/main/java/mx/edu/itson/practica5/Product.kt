package mx.edu.itson.practica5

data class Product(var name:String,
                    var image:Int,
                    var description:String,
                    var price:Double)
